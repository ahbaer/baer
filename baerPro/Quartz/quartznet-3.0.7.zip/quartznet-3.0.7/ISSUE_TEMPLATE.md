<!-- For feature requests, just clear out the below -->

### Version: x.y.z
<!-- Include the major/minor version (4.2.1, 5.2.0, 6.0.2 etc) --> 

### Expected behavior

<!-- What did you expect to happen? Or what used to happen in an older version? -->

### Actual behavior

<!-- What happened instead? -->

### Steps to reproduce

```csharp
// scheduler and job configuration, SystemTime prefereably set to fixed point
```
